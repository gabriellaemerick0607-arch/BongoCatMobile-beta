# Bongo Cat Mobile — projeto e compilação na nuvem

Este projeto é um protótipo. Não é um APK pronto.

## Gerar o APK sem instalar Android Studio (usando GitHub pelo navegador)

1. Crie/entre na sua conta em https://github.com
2. Clique no `+` no topo e escolha **New repository**.
3. Dê o nome `BongoCatMobile` e escolha **Public** (necessário para usar Actions sem configuração extra em alguns planos); crie o repositório.
4. Na página do repositório, escolha **Add file > Upload files** e envie os arquivos/pastas deste projeto. Garanta que a pasta `.github/workflows` e o arquivo `build-apk.yml` sejam incluídos. Se o navegador não permitir enviar a pasta oculta `.github`, crie o arquivo manualmente pelo site em **Add file > Create new file**, com o caminho `.github/workflows/build-apk.yml`, e copie o conteúdo do arquivo de workflow que está no ZIP.
5. Clique em **Commit changes**.
6. Abra a aba **Actions**. Se aparecer uma pergunta para habilitar workflows, habilite.
7. Selecione **Gerar APK do Bongo Cat Mobile** e clique em **Run workflow** (ou aguarde o primeiro build iniciado pelo commit).
8. Quando terminar com um visto verde, abra a execução e procure **Artifacts**. Baixe `BongoCatMobile-APK.zip`.
9. Extraia esse ZIP: dentro estará `app-debug.apk`. Transfira-o para o celular e abra o arquivo para instalar. Talvez seja necessário permitir a instalação dessa fonte nas configurações do Android.

## Segurança e limitações
- O APK de debug é um protótipo para teste, não uma versão publicada na Play Store.
- Instale APKs apenas de projetos que você confia. Não coloque senhas nem chaves pessoais no repositório.
- O personagem reage a toques e eventos de teclado/mouse enquanto o app está aberto; ainda não fica por cima de outros apps.
