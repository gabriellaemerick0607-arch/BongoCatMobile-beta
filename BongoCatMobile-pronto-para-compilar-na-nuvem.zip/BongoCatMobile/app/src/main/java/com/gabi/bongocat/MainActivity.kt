package com.gabi.bongocat

import android.app.Activity
import android.os.Bundle
import android.graphics.Color
import android.view.Gravity
import android.view.KeyEvent
import android.view.MotionEvent
import android.view.View
import android.widget.*

class MainActivity : Activity() {
    private lateinit var catView: CatView
    private lateinit var status: TextView
    private var skin = "Branquinho"
    private var colorName = "Arco-íris"
    private var effect = "Neon"

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.statusBarColor = Color.rgb(16,13,34)
        window.navigationBarColor = Color.rgb(16,13,34)

        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER_HORIZONTAL
            setPadding(18, 18, 18, 18)
            setBackgroundColor(Color.rgb(16,13,34))
            isFocusableInTouchMode = true
        }
        val title = TextView(this).apply {
            text = "🐾 BONGO CAT MOBILE"
            textSize = 25f
            setTextColor(Color.WHITE)
            gravity = Gravity.CENTER
            typeface = android.graphics.Typeface.DEFAULT_BOLD
        }
        root.addView(title, LinearLayout.LayoutParams(-1, 58))
        val subtitle = TextView(this).apply {
            text = "Conecte teclado ou mouse e divirta-se!"
            textSize = 14f
            setTextColor(Color.rgb(205,190,255))
            gravity = Gravity.CENTER
        }
        root.addView(subtitle, LinearLayout.LayoutParams(-1, 32))

        catView = CatView(this)
        root.addView(catView, LinearLayout.LayoutParams(-1, 0, 1f))

        status = TextView(this).apply {
            text = "Toque na tela, digite ou clique para animar."
            textSize = 13f
            setTextColor(Color.WHITE)
            gravity = Gravity.CENTER
            setPadding(0, 8, 0, 8)
        }
        root.addView(status, LinearLayout.LayoutParams(-1, 42))

        addSelector(root, "🐱 Personagem", arrayOf("Branquinho", "Gatinho preto", "Laranjinha", "Cinzentinho", "Gatinho de fone", "Pixel cat", "Sapo fofo", "Gatinho sonolento", "Gatinho pirata")) { skin = it; catView.skin = it; catView.invalidate() }
        addSelector(root, "🌈 Teclado e mouse", arrayOf("Arco-íris", "Azul", "Rosa", "Verde", "Roxo", "Vermelho", "Amarelo", "Ciano", "Branco")) { colorName = it; catView.colorName = it; catView.invalidate() }
        addSelector(root, "✨ Efeito", arrayOf("Neon", "Pixel art", "Fofo", "Brilho", "Sem efeito")) { effect = it; catView.effect = it; catView.invalidate() }

        val note = TextView(this).apply {
            text = "Atenção: esta versão reage enquanto está aberta. O suporte em outros apps exige recursos e permissões extras do Android."
            textSize = 11f
            setTextColor(Color.rgb(180,170,210))
            gravity = Gravity.CENTER
            setPadding(0, 10, 0, 0)
        }
        root.addView(note, LinearLayout.LayoutParams(-1, 50))
        setContentView(root)
        root.requestFocus()
    }

    private fun addSelector(root: LinearLayout, label: String, items: Array<String>, changed: (String) -> Unit) {
        val row = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL }
        val text = TextView(this).apply {
            this.text = label
            textSize = 14f
            setTextColor(Color.WHITE)
        }
        row.addView(text, LinearLayout.LayoutParams(145, 48))
        val spinner = Spinner(this)
        spinner.adapter = ArrayAdapter(this, android.R.layout.simple_spinner_dropdown_item, items)
        spinner.setBackgroundColor(Color.rgb(44,35,72))
        spinner.onItemSelectedListener = object : android.widget.AdapterView.OnItemSelectedListener {
            override fun onItemSelected(parent: android.widget.AdapterView<*>?, view: View?, position: Int, id: Long) = changed(items[position])
            override fun onNothingSelected(parent: android.widget.AdapterView<*>?) {}
        }
        row.addView(spinner, LinearLayout.LayoutParams(0, 48, 1f))
        root.addView(row, LinearLayout.LayoutParams(-1, 48))
    }

    override fun onKeyDown(keyCode: Int, event: KeyEvent?): Boolean {
        status.text = "⌨️ Tecla pressionada: ${event?.displayLabel ?: keyCode}"
        catView.animateTap()
        return true
    }

    override fun onGenericMotionEvent(event: MotionEvent): Boolean {
        if (event.action == MotionEvent.ACTION_HOVER_MOVE || event.action == MotionEvent.ACTION_BUTTON_PRESS) {
            status.text = "🖱️ Mouse em ação!"
            catView.animateTap()
            return true
        }
        return super.onGenericMotionEvent(event)
    }
}

class CatView(context: android.content.Context) : View(context) {
    var skin = "Branquinho"
    var colorName = "Arco-íris"
    var effect = "Neon"
    private var taps = 0
    private val p = android.graphics.Paint(android.graphics.Paint.ANTI_ALIAS_FLAG)

    fun animateTap() { taps++; invalidate() }

    private fun accent(): Int = when(colorName) {
        "Azul" -> Color.rgb(40,180,255)
        "Rosa" -> Color.rgb(255,90,190)
        "Verde" -> Color.rgb(60,255,150)
        "Roxo" -> Color.rgb(170,80,255)
        "Vermelho" -> Color.rgb(255,65,75)
        "Amarelo" -> Color.rgb(255,220,50)
        "Ciano" -> Color.rgb(50,255,240)
        "Branco" -> Color.WHITE
        else -> listOf(Color.RED, Color.YELLOW, Color.GREEN, Color.CYAN, Color.BLUE, Color.MAGENTA)[taps % 6]
    }

    override fun onDraw(canvas: android.graphics.Canvas) {
        super.onDraw(canvas)
        val w = width.toFloat(); val h = height.toFloat()
        canvas.drawColor(Color.rgb(25,20,48))
        p.style = android.graphics.Paint.Style.FILL
        p.color = if(effect == "Neon") accent() else Color.rgb(104,73,170)
        canvas.drawRoundRect(w*.06f,h*.06f,w*.94f,h*.94f,28f,28f,p)

        // Keyboard
        p.color = Color.rgb(26,22,43)
        canvas.drawRoundRect(w*.12f,h*.70f,w*.88f,h*.88f,18f,18f,p)
        val cols = 10; val rows = 3
        for (r in 0 until rows) for (c in 0 until cols) {
            p.color = if(colorName == "Arco-íris") Color.HSVToColor(floatArrayOf((c*28f+r*16f)%360, .8f, 1f)) else accent()
            val x = w*.16f + c*w*.068f
            val y = h*.73f + r*h*.045f
            canvas.drawRoundRect(x,y,x+w*.052f,y+h*.028f,4f,4f,p)
        }
        // Cat head / ears
        val fur = when(skin) {
            "Gatinho preto" -> Color.rgb(40,38,54)
            "Laranjinha" -> Color.rgb(255,174,83)
            "Cinzentinho" -> Color.rgb(175,180,195)
            "Gatinho de fone" -> Color.WHITE
            "Sapo fofo" -> Color.rgb(110,220,125)
            "Gatinho pirata" -> Color.rgb(245,235,220)
            else -> Color.WHITE
        }
        p.color = fur
        val cx = w*.5f; val cy = h*.43f; val r = w*.23f
        val ear = android.graphics.Path().apply { moveTo(cx-r*.78f,cy-r*.35f); lineTo(cx-r*.65f,cy-r*1.18f); lineTo(cx-r*.18f,cy-r*.72f); close() }
        canvas.drawPath(ear,p)
        val ear2 = android.graphics.Path().apply { moveTo(cx+r*.78f,cy-r*.35f); lineTo(cx+r*.65f,cy-r*1.18f); lineTo(cx+r*.18f,cy-r*.72f); close() }
        canvas.drawPath(ear2,p)
        canvas.drawCircle(cx,cy,r,p)
        // Face
        p.color = if(skin == "Gatinho preto") Color.WHITE else Color.rgb(35,30,45)
        canvas.drawCircle(cx-r*.35f,cy-r*.05f,r*.07f,p)
        canvas.drawCircle(cx+r*.35f,cy-r*.05f,r*.07f,p)
        p.style = android.graphics.Paint.Style.STROKE; p.strokeWidth = 5f; p.strokeCap = android.graphics.Paint.Cap.ROUND
        val face = android.graphics.Path().apply { moveTo(cx-r*.12f,cy+r*.12f); quadTo(cx,cy+r*.28f,cx+r*.12f,cy+r*.12f) }
        canvas.drawPath(face,p); p.style = android.graphics.Paint.Style.FILL
        p.color = Color.rgb(255,145,180)
        canvas.drawCircle(cx-r*.53f,cy+r*.17f,r*.10f,p); canvas.drawCircle(cx+r*.53f,cy+r*.17f,r*.10f,p)
        // Paws tapping
        val pawY = cy + r*.65f + if(taps % 2 == 0) 0 else -12f
        p.color = fur
        canvas.drawOval(cx-r*.9f,pawY,cx-r*.15f,pawY+r*.55f,p)
        canvas.drawOval(cx+r*.15f,pawY,cx+r*.9f,pawY+r*.55f,p)
        p.color = Color.rgb(255,145,180)
        canvas.drawCircle(cx-r*.52f,pawY+r*.32f,r*.10f,p)
        canvas.drawCircle(cx+r*.52f,pawY+r*.32f,r*.10f,p)
        // Labels
        p.color = Color.WHITE; p.textSize = 30f; p.textAlign = android.graphics.Paint.Align.CENTER
        canvas.drawText(if(effect == "Pixel art") "PIXEL CAT" else "BONGO CAT", cx, h*.96f, p)
    }

    override fun onTouchEvent(event: MotionEvent): Boolean {
        if(event.action == MotionEvent.ACTION_DOWN) { animateTap(); return true }
        return true
    }
}
